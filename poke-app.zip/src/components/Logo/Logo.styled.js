import styled from 'styled-components';
import { Link } from 'react-router-dom';

export const Logo = styled(Link)`
  display: flex;
  justify-content: center;
  text-decoration: none;

  .logotype {
    margin-right: 13px;
    display: flex;
  }

  .header {
    font-size: 20px;
    font-weight: 700;
    color: white;

    @media (min-width: 640px) {
      font-size: 34px;
    }
  }
`;
